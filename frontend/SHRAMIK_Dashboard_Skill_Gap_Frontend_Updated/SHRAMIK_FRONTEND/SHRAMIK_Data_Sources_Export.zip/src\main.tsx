import { createRoot } from 'react-dom/client';
import { DataSourcesPage } from './data-sources/DataSourcesPage';
import { mockDataSourcesAdapter } from './data-sources/mock-adapter';
import './styles.css';

createRoot(document.getElementById('root')!).render(<DataSourcesPage adapter={mockDataSourcesAdapter} />);
