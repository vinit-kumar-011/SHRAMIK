import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { DataSourcesPage } from './DataSourcesPage';
import { mockDataSourcesAdapter } from './mock-adapter';

describe('DataSourcesPage', () => {
 it('combines local registry filters and resets them', async () => {
  const user = userEvent.setup(); render(<DataSourcesPage adapter={mockDataSourcesAdapter} />);
  await screen.findAllByText('PLFS (Periodic Labour Force Survey)');
  await user.type(screen.getByLabelText('Search sources'), 'naukri');
  expect((await screen.findAllByText('Job Postings — Naukri (Demo)')).length).toBeGreaterThan(0);
  expect(screen.queryByText('e-Shram Registrations')).not.toBeTruthy();
  await user.click(screen.getByRole('button', { name: 'Reset filters' }));
  expect((await screen.findAllByText('e-Shram Registrations')).length).toBeGreaterThan(0);
 });
 it('opens a drawer and renders independent detail tabs', async () => {
  const user = userEvent.setup(); render(<DataSourcesPage adapter={mockDataSourcesAdapter} />);
  await screen.findAllByText('PLFS (Periodic Labour Force Survey)');
  await user.click(screen.getAllByRole('button', { name: /view/i })[0]);
  expect((await screen.findByRole('dialog')).textContent).toContain('SYNTHETIC_DEMO');
  await user.click(screen.getByRole('tab', { name: 'Data coverage' }));
  expect((await screen.findByText(/Coverage state:/)).textContent).toContain('UNKNOWN');
  await user.click(screen.getByRole('tab', { name: 'Field mapping' }));
  expect(await screen.findByText('example_source_field')).toBeTruthy();
  await user.click(screen.getByLabelText('Close details'));
  await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeTruthy());
  expect(document.activeElement).toBe(screen.getAllByRole('button', { name: /view/i })[0]);
 });
 it('shows a truthful not-configured state', async () => {
  const user = userEvent.setup(); render(<DataSourcesPage adapter={mockDataSourcesAdapter} />);
  await screen.findAllByText('Job Postings — Naukri (Demo)');
  await user.click(screen.getAllByRole('button', { name: /view/i })[5]);
  await user.click(screen.getByRole('tab', { name: 'Ingestion history' }));
  expect(await screen.findByText(/No ingestion history is configured/)).toBeTruthy();
 });
});
