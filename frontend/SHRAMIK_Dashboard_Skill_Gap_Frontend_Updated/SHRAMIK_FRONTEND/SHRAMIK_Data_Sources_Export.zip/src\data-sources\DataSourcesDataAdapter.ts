import type {
  CoverageSummary,
  DataSourceRecord,
  FieldMappingRecord,
  IngestionRunRecord,
  PagedResult,
  SourceError,
  SourceListQuery,
  SourceType,
  SourceLifecycleStatus,
} from "./data-sources.types";

export interface DataSourcesDataAdapter {
  listSources(query: SourceListQuery): Promise<PagedResult<DataSourceRecord>>;
  getSource(sourceId: string): Promise<DataSourceRecord>;
  listIngestionRuns(
    sourceId: string,
    options?: { page?: number; pageSize?: number },
  ): Promise<PagedResult<IngestionRunRecord>>;
  getCoverage(sourceId: string): Promise<CoverageSummary>;
  getFieldMappings(
    sourceId: string,
    schemaVersion?: string,
  ): Promise<PagedResult<FieldMappingRecord>>;

  /** Optional capability-based operations. Reject with a typed-safe error when unsupported. */
  createSource?(input: CreateSourceInput): Promise<DataSourceRecord>;
  requestIngestion?(sourceId: string): Promise<{ runId: string; status: "QUEUED" | "RUNNING" }>;
  updateSource?(sourceId: string, patch: UpdateSourceInput): Promise<DataSourceRecord>;
}

export interface CreateSourceInput {
  name: string;
  type: SourceType;
  agencyOwner?: string;
  purpose?: string;
  tags?: string[];
}

export interface UpdateSourceInput {
  name?: string;
  agencyOwner?: string;
  purpose?: string;
  lifecycleStatus?: SourceLifecycleStatus;
  tags?: string[];
}

export class DataSourcesAdapterError extends Error {
  constructor(public readonly detail: SourceError) {
    super(detail.message);
    this.name = "DataSourcesAdapterError";
  }
}
