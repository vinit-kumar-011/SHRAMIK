import data from './mock-data-sources.json';
import type { DataSourcesDataAdapter } from './DataSourcesDataAdapter';
import type { CoverageSummary, DataSourceRecord, FieldMappingRecord, IngestionRunRecord, PagedResult, SourceListQuery } from './data-sources.types';

const fixture = data as unknown as { items: DataSourceRecord[]; ingestionRunsBySource: Record<string, IngestionRunRecord[]>; coverageBySource: Record<string, CoverageSummary>; fieldMappingsBySource: Record<string, FieldMappingRecord[]> };
const page = <T,>(items: T[], number = 1, pageSize = 8): PagedResult<T> => ({ items: items.slice((number - 1) * pageSize, number * pageSize), total: items.length, page: number, pageSize, provenance: 'SYNTHETIC_DEMO' });
const match = (value: string | undefined | null, query: string) => value?.toLowerCase().includes(query) ?? false;

export const mockDataSourcesAdapter: DataSourcesDataAdapter = {
  async listSources(query: SourceListQuery) {
    const needle = query.query?.trim().toLowerCase() ?? '';
    const items = fixture.items.filter(s => (!needle || [s.name, s.agencyOwner, s.type, ...s.tags].some(v => match(v, needle))) && (!query.status || query.status === 'ALL' || s.lifecycleStatus === query.status) && (!query.type || query.type === 'ALL' || s.type === query.type) && (!query.agency || query.agency === 'ALL' || s.agencyOwner === query.agency));
    const result = page(items, query.page, query.pageSize);
    return { ...result, summary: { total: items.length, active: items.filter(s => s.lifecycleStatus === 'ACTIVE').length, needsAttention: items.filter(s => ['PENDING_VALIDATION', 'STALE', 'FAILED'].includes(s.lifecycleStatus)).length, notConfigured: items.filter(s => s.lifecycleStatus === 'NOT_CONFIGURED').length } };
  },
  async getSource(id) { const source = fixture.items.find(s => s.id === id); if (!source) throw new Error('Source not found'); return source; },
  async listIngestionRuns(id, options) { return page(fixture.ingestionRunsBySource[id] ?? [], options?.page, options?.pageSize); },
  async getCoverage(id) { return fixture.coverageBySource[id] ?? { sourceId: id, geography: [], reportingPeriods: [], state: 'NOT_CONFIGURED', limitations: ['Coverage is not configured for this illustrative source.'], provenance: 'SYNTHETIC_DEMO' }; },
  async getFieldMappings(id) { return page(fixture.fieldMappingsBySource[id] ?? []); }
};
